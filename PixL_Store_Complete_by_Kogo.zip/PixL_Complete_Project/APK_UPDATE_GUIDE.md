# 📁 APKファイル選択機能 - Fortnite更新ガイド

## 🎯 新機能概要
PixL Storeに**APKファイル選択機能**が追加され、Fortniteの手動更新が可能になりました！

## 🔄 更新手順

### 1️⃣ **APK取得**
以下のソースからFortnite APKを入手：
- **APKMirror**: https://www.apkmirror.com/apk/epic-games/fortnite/
- **APKPure**: https://apkpure.com/fortnite/com.epicgames.fortnite
- **友人・コミュニティ**: 信頼できるソースのみ
- **バックアップ**: 既存インストール済みAPKの抽出

### 2️⃣ **PixLでの更新操作**
```
1. PixL Store起動
2. 「Fortnite」をタップ
3. 「📁 APKファイル選択」ボタンをタップ
4. ファイルマネージャーで新しいFortnite APKを選択
5. 自動コピー完了まで待機
6. 「インストール」ボタンでアップデート
```

### 3️⃣ **VoiD FX設定の再適用**
Fortnite更新後は設定がリセットされるため：
```
1. VoiD FXを起動
2. 希望のFPS設定を選択（120fps / 10000fps等）
3. 軽量化モードなどの設定を再調整
4. 「設定を適用」をタップ
5. Fortnite起動（ゲーム内設定は開かない！）
```

## 🛠️ 技術実装詳細

### **新追加機能**
- `selectApkButton`: APK選択専用ボタン（Fortnite限定表示）
- `onSelectApkClick()`: ファイル選択ダイアログ起動
- `copySelectedApkFile()`: 選択APKを内部ストレージにコピー
- `onActivityResult()`: ファイル選択結果の処理

### **ファイル管理**
- **保存場所**: `/Android/data/com.kogo.pixlstore/files/apks/Fortnite.apk`
- **検証機能**: ファイルサイズ・整合性チェック
- **上書き対応**: 既存APKを自動削除→新APKで置換

### **UI改善**
- **動的ボタン表示**: Fortniteの場合のみAPK選択ボタン表示
- **プログレス表示**: コピー進行状況をリアルタイム表示
- **自動インストール確認**: コピー完了後に即座にインストール提案

## 📱 UI変更箇所

### **AppDetailActivity.java**
- `REQUEST_CODE_SELECT_APK = 1001`: ファイル選択リクエストコード
- `selectApkButton`: 新規ボタン追加
- `onSelectApkClick()`: APK選択処理
- `copySelectedApkFile()`: バックグラウンドでファイルコピー

### **activity_app_detail.xml**
- APK選択ボタン追加（Fortnite専用）
- 使用方法ガイドをUI内に埋め込み
- ファイルアイコン付きボタンデザイン

## ⚠️ 重要な注意事項

### **セキュリティ**
- **信頼できるソースのみ**: マルウェア混入APKに注意
- **ウイルススキャン**: APK選択前にスキャン推奨
- **公式署名確認**: 可能なら開発者署名をチェック

### **Epic Games規約**
- **アカウントBAN**: 修正版APK使用でアカウント停止リスク
- **自己責任**: 利用規約違反は自己責任
- **検出回避**: 現在のEpicの検出システムは強化済み

## 🔧 トラブルシューティング

### **よくある問題**
1. **「ファイルマネージャーが見つかりません」**
   - Google Files等のファイルマネージャーをインストール

2. **「コピーに失敗しました」**
   - ストレージ容量不足→空き容量を確保
   - 権限不足→アプリ権限でストレージアクセスを許可

3. **「インストールに失敗しました」**
   - 提供元不明のアプリを許可
   - 既存Fortniteをアンインストール

4. **「APKが見つかりません」**
   - ダウンロードフォルダを確認
   - ファイル名に`.apk`拡張子があることを確認

## 🚀 使用推奨環境
- **Android**: 8.0以上
- **ストレージ**: 最低8GB空き容量
- **RAM**: 4GB以上推奨
- **デバイス**: RedMagic 9 Pro等のゲーミング端末

---

**🎮 PixL Store - Fortnite & VoiD FX統合管理**  
**開発者**: こうご  
**目的**: 安全で便利なFortnite管理環境の提供