# 🎮 PixL代用アプリ - 超詳細ビルド手順書

## 📥 **ステップ1: ファイルのダウンロード**

### 方法1: 直接ダウンロード
```
1. 上のチャット画面で [pixl_project] リンクをクリック
2. ブラウザで開かれたら、右クリック → 「名前を付けて保存」
3. フォルダ全体をダウンロード
```

### 方法2: 個別ファイル取得
各ファイルを個別にコピー&ペーストで作成する方法：

1. **新しいフォルダ作成**
```
デスクトップに「pixl_project」フォルダを作成
```

2. **Android Studioプロジェクト構造作成**
```
pixl_project/
├── pixl_store/
│   ├── app/
│   │   ├── src/
│   │   │   └── main/
│   │   │       ├── java/
│   │   │       │   └── com/
│   │   │       │       └── kogo/
│   │   │       │           └── pixlstore/
│   │   │       ├── res/
│   │   │       │   ├── layout/
│   │   │       │   ├── values/
│   │   │       │   └── xml/
│   │   │       └── AndroidManifest.xml
│   │   └── build.gradle
│   └── build.gradle
└── README.md
```

## 🛠️ **ステップ2: Android Studio準備**

### 2-1. Android Studioインストール
```
1. https://developer.android.com/studio にアクセス
2. 「Download Android Studio」をクリック
3. インストーラーをダウンロード・実行
4. インストール時に「Android SDK」も一緒にインストール
```

### 2-2. SDKの設定
```
1. Android Studio起動
2. Welcome画面で「Configure」→「SDK Manager」
3. 以下をインストール:
   - Android API 26 (Android 8.0)
   - Android API 34 (Android 14)
   - Android SDK Build-Tools 34.0.0
```

## 📱 **ステップ3: プロジェクト設定**

### 3-1. プロジェクトを開く
```
1. Android Studio起動
2. 「Open an existing Android Studio project」選択
3. ダウンロードした「pixl_store」フォルダを選択
4. 「OK」をクリック
```

### 3-2. 初回同期
```
1. プロジェクトが開いたら自動的にGradle同期開始
2. 右上に「Sync Now」が表示されたらクリック
3. 同期完了まで待機（数分かかる場合あり）
```

## 🔧 **ステップ4: 不足ファイルの追加**

Android Studioでプロジェクトを開いた後、以下のファイルが不足している場合があります：

### 4-1. gradle-wrapper.properties作成
```
ファイル場所: pixl_store/gradle/wrapper/gradle-wrapper.properties

内容:
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.0-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```

### 4-2. gradlew / gradlew.bat作成
```
Android Studioで:
1. File → New → File
2. 「gradlew」という名前でファイル作成
3. 内容は空でOK（Android Studioが自動生成）
```

### 4-3. 足りないリソース追加
```
res/drawable/ フォルダに以下を追加:
- ic_launcher.xml (アプリアイコン)
- fortnite_icon.xml (Fortniteアイコン) 
- voidfx_icon.xml (VoiD FXアイコン)
- ic_android.xml (デフォルトアイコン)
- ic_arrow_forward.xml (矢印アイコン)
```

## 🎯 **ステップ5: APKビルド**

### 5-1. デバッグ版APK（テスト用）
```
1. Android Studioのメニューで「Build」→「Build Bundle(s)/APK(s)」→「Build APK(s)」
2. 右下に「APK(s) generated successfully」と表示されるまで待つ
3. 「locate」をクリックしてAPKファイルの場所を確認
4. 生成場所: app/build/outputs/apk/debug/app-debug.apk
```

### 5-2. リリース版APK（本格使用）
```
1. 「Build」→「Generate Signed Bundle/APK」
2. 「APK」を選択して「Next」
3. キーストア設定:
   - 「Create new...」を選択
   - 適当なパスワードと情報を入力
   - 「OK」をクリック
4. 「Release」を選択して「Finish」
5. 生成場所: app/release/app-release.apk
```

## 📲 **ステップ6: APKインストール**

### 6-1. 端末でインストール準備
```
1. 設定 → セキュリティ → 提供元不明のアプリ → 許可
2. 設定 → アプリ → 特別なアプリアクセス → 端末管理アプリ → 許可
```

### 6-2. APKをスマホに転送
```
方法1: USBケーブル
1. APKファイルをスマホにコピー
2. ファイルマネージャーでAPKをタップ
3. インストールを実行

方法2: Google Drive
1. APKをGoogle Driveにアップロード
2. スマホでダウンロード
3. インストールを実行
```

## 🎮 **ステップ7: アプリ使用方法**

### 7-1. 初回起動
```
1. PixL Storeアプリを起動
2. 必要な権限をすべて許可
3. メイン画面でFortniteとVoiD FXを確認
```

### 7-2. Fortnite 120fps化
```
1. 端末設定で120Hz表示モードを有効
2. PixL Store → Fortnite → ダウンロード&インストール
3. Fortniteを起動してログイン
4. PixL Store → VoiD FX → 120fps選択 → 設定適用
5. Fortniteでプレイ（⚠️ゲーム内設定は開かない）
```

## ⚠️ **トラブルシューティング**

### エラー1: 「Gradle sync failed」
```
解決方法:
1. File → Invalidate Caches and Restart
2. Build → Clean Project
3. Build → Rebuild Project
```

### エラー2: 「SDK not found」
```
解決方法:
1. File → Project Structure → SDK Location
2. Android SDK Locationを確認・設定
3. 通常は: C:\Users\ユーザー名\AppData\Local\Android\Sdk
```

### エラー3: 「Build failed」
```
解決方法:
1. Build → Clean Project
2. File → Sync Project with Gradle Files
3. 再度Build実行
```

### エラー4: APKインストール失敗
```
解決方法:
1. 提供元不明のアプリを許可
2. 古いバージョンをアンインストール
3. 端末を再起動して再試行
```

## 📞 **追加サポート**

### よくある質問
**Q: Android Studioが重い**
A: RAMを8GB以上推奨、SSDストレージ使用

**Q: ビルドに時間がかかる**
A: 初回は時間がかかります。2回目以降は高速化されます

**Q: APKサイズが大きい**
A: デバッグ版は大きくなります。リリース版は最適化されます

---
**作成者**: こうご専用カスタム版
**バージョン**: 1.0  
**注意**: 使用は自己責任でお願いします