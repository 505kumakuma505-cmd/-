# 🎮 PixL Store - 完全版 (by こうご)

## 📱 **完成アプリ概要**
**PixL Store**: Fortnite & VoiD FX統合管理プラットフォーム  
**開発目的**: 廃止されたPixLの完全代替 + 高度機能追加

---

## ✨ **主要機能**

### 🎯 **PixL Store (統合管理)**
- **Fortnite管理**: インストール・起動・APK更新
- **📁 APKファイル選択**: 手動でFortnite APKを更新可能
- **VoiD FX統合**: GameUserSettings.ini & Engine.ini編集
- **ダークテーマUI**: 高級感のある日本語完全対応

### ⚙️ **VoiD FX (モバイル専用最適化)**
- **拡張FPS対応**: 30/60/120/144/165/180/200/240/360/10000fps
- **軽量化モード**: ScalabilityGroups一括設定
- **モバイル最適化**: タッチ入力遅延削減・オーディオ最適化
- **Engine.ini自動生成**: レンダリング・入力最適化

---

## 🚀 **使用手順**

### **1️⃣ ビルド・インストール**
```bash
1. Android Studioを起動
2. 「Open Existing Project」で pixl_store フォルダを選択
3. Gradle Sync完了後、「Build > Build Bundle(s)/APK(s) > Build APK(s)」
4. 生成されたAPKをRedMagic 9 Proにインストール
```

### **2️⃣ Fortnite更新 (新機能)**
```bash
1. APKMirror等から最新Fortnite APKをダウンロード
2. PixL Store起動 > 「Fortnite」選択
3. 「📁 APKファイル選択」> ダウンロードしたAPKを選択
4. 自動コピー完了後「インストール」
```

### **3️⃣ VoiD FX設定適用**
```bash
1. PixL Store > 「VoiD FX」選択
2. FPS設定: 「10000fps (無制限)」選択
3. 軽量化モード: ON
4. タッチレイテンシ最適化: ON
5. 「設定を適用」> Fortnite起動
⚠️ ゲーム内設定メニューは絶対に開かない！
```

---

## 📁 **プロジェクト構造**
```
PixL_Complete_Project/
├── pixl_store/                    # メインアプリケーション
│   ├── app/src/main/
│   │   ├── java/com/kogo/pixlstore/
│   │   │   ├── MainActivity.java          # PixL Store メイン画面
│   │   │   ├── AppDetailActivity.java     # APK選択・管理機能 ⭐NEW
│   │   │   └── VoidFxActivity.java        # モバイル専用VoiD FX ⭐NEW  
│   │   └── res/layout/
│   │       ├── activity_main.xml
│   │       ├── activity_app_detail.xml    # APK選択UI ⭐NEW
│   │       └── activity_void_fx.xml       # モバイル最適化UI ⭐NEW
│   ├── build.gradle
│   └── AndroidManifest.xml
├── BUILD_INSTRUCTIONS.md          # 詳細ビルド手順
├── APK_UPDATE_GUIDE.md            # APK更新ガイド ⭐NEW
├── MOBILE_OPTIMIZATION_GUIDE.md   # モバイル最適化ガイド ⭐NEW
└── README.md                      # このファイル
```

---

## 🎯 **RedMagic 9 Pro 推奨設定**

### **最高パフォーマンス設定**
- **FPS**: 10000fps (無制限)
- **軽量化モード**: ON (全ScalabilityGroups = 0)
- **タッチレイテンシ最適化**: ON
- **FPS表示**: ON (モニタリング用)
- **その他**: 草表示OFF、モーションブラーOFF、VsyncOFF

### **安定重視設定**
- **FPS**: 120fps (安定動作)
- **軽量化モード**: ON
- **DLSS**: OFF (モバイル非対応)
- **レイトレーシング**: OFF

---

## ⚠️ **重要な注意事項**

### **法的リスク**
- **Epic Games利用規約違反**: 修正版APK使用でアカウントBAN可能性
- **自己責任**: 全ての使用は自己責任で実行
- **検出システム**: 現在のEpicは強化された検出システム運用中

### **技術的制約**
- **ゲーム内設定厳禁**: 設定メニューを開くとFPS設定リセット
- **デバイス依存**: 一部設定は端末性能に依存
- **APKソース**: 信頼できるソースのAPKのみ使用

---

## 🔧 **トラブルシューティング**

### **ビルドエラー**
- **Gradle同期失敗**: SDK Manager > Android SDK > 最新バージョンをインストール
- **コンパイルエラー**: Java 8以上、Gradle 7.0以上必要

### **APK選択エラー**
- **ファイルマネージャー未検出**: Google Files等をインストール  
- **コピー失敗**: ストレージ容量不足確認

### **VoiD FX適用エラー**
- **権限不足**: アプリ設定 > ストレージ権限を許可
- **設定リセット**: Fortnite再インストール後は設定再適用必要

---

## 📞 **サポート情報**

**開発者**: こうご（考悟）  
**対象端末**: RedMagic 9 Pro 最適化済み  
**Android要件**: 8.0以上、4GB RAM以上  
**用途**: Fortnite 120fps+ ゲーミング環境

---

## 🏆 **完成度**
- ✅ **PixL Store**: 完全機能実装
- ✅ **VoiD FX**: モバイル専用最適化完了  
- ✅ **APK更新**: 手動選択システム実装 ⭐NEW
- ✅ **UI/UX**: 日本語完全対応・ダークテーマ
- ✅ **ドキュメント**: 詳細ガイド完備

**🎮 Enjoy ultimate Fortnite gaming with PixL Store! 🎮**