package com.kogo.pixlstore;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class VoidFxActivity extends AppCompatActivity {

    private Spinner fpsSpinner;
    private Switch showFpsSwitch;
    private Switch dlssSwitch;
    private Switch cosmeticStreamingSwitch;
    private Switch antiAliasingSwitch;
    private Switch vsyncSwitch;
    private Switch videoPlaybackSwitch;
    private Switch motionBlurSwitch;
    private Switch grassSwitch;
    
    // モバイル最適化設定
    private Switch lightweightModeSwitch;
    private Switch rayTracingSwitch;
    private Switch naniteSwitch;
    private Switch latencyOptSwitch;
    
    private TextView warningText;
    private Button applyButton;

    private SharedPreferences preferences;
    
    // 拡張FPSオプション（10000fps追加）
    private final String[] fpsOptions = {"30 FPS", "60 FPS", "120 FPS", "144 FPS", "165 FPS", "180 FPS", "200 FPS", "240 FPS", "360 FPS", "10000 FPS (無制限)"};
    private final String[] fpsModes = {"Mode_30Fps", "Mode_60Fps", "Mode_120Fps", "Mode_144Fps", "Mode_165Fps", "Mode_180Fps", "Mode_200Fps", "Mode_240Fps", "Mode_360Fps", "Mode_10000Fps"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_void_fx_mobile);

        initializeViews();
        setupSpinners();
        loadSettings();
    }

    private void initializeViews() {
        fpsSpinner = findViewById(R.id.fpsSpinner);
        showFpsSwitch = findViewById(R.id.showFpsSwitch);
        dlssSwitch = findViewById(R.id.dlssSwitch);
        cosmeticStreamingSwitch = findViewById(R.id.cosmeticStreamingSwitch);
        antiAliasingSwitch = findViewById(R.id.antiAliasingSwitch);
        vsyncSwitch = findViewById(R.id.vsyncSwitch);
        videoPlaybackSwitch = findViewById(R.id.videoPlaybackSwitch);
        motionBlurSwitch = findViewById(R.id.motionBlurSwitch);
        grassSwitch = findViewById(R.id.grassSwitch);
        
        // モバイル最適化設定
        lightweightModeSwitch = findViewById(R.id.lightweightModeSwitch);
        rayTracingSwitch = findViewById(R.id.rayTracingSwitch);
        naniteSwitch = findViewById(R.id.naniteSwitch);
        latencyOptSwitch = findViewById(R.id.latencyOptSwitch);
        
        warningText = findViewById(R.id.warningText);
        applyButton = findViewById(R.id.applyButton);

        preferences = getSharedPreferences("VoidFxSettings", MODE_PRIVATE);

        // 警告テキスト設定
        warningText.setText("⚠️ 重要な注意事項 ⚠️\n" +
                          "• 設定適用後は、ゲーム内の設定メニューを開かないでください\n" +
                          "• 10000fps設定は実験的機能です\n" +
                          "• 軽量化設定でパフォーマンス大幅向上\n" +
                          "• 本機能の使用によるアカウントBANは自己責任です");

        applyButton.setOnClickListener(this::onApplySettings);
        
        // 軽量化モード設定時の自動調整
        lightweightModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                autoConfigureLightweightMode();
            }
        });
    }

    private void setupSpinners() {
        ArrayAdapter<String> fpsAdapter = new ArrayAdapter<>(this, 
            android.R.layout.simple_spinner_item, fpsOptions);
        fpsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fpsSpinner.setAdapter(fpsAdapter);
    }

    private void loadSettings() {
        int fpsIndex = preferences.getInt("fps_index", 2);
        fpsSpinner.setSelection(fpsIndex);

        showFpsSwitch.setChecked(preferences.getBoolean("show_fps", true));
        dlssSwitch.setChecked(preferences.getBoolean("dlss", false));
        cosmeticStreamingSwitch.setChecked(preferences.getBoolean("cosmetic_streaming", true));
        antiAliasingSwitch.setChecked(preferences.getBoolean("anti_aliasing", false));
        vsyncSwitch.setChecked(preferences.getBoolean("vsync", false));
        videoPlaybackSwitch.setChecked(preferences.getBoolean("video_playback", true));
        motionBlurSwitch.setChecked(preferences.getBoolean("motion_blur", false));
        grassSwitch.setChecked(preferences.getBoolean("grass", false));
        
        // モバイル最適化設定ロード
        lightweightModeSwitch.setChecked(preferences.getBoolean("lightweight_mode", false));
        rayTracingSwitch.setChecked(preferences.getBoolean("ray_tracing", false));
        naniteSwitch.setChecked(preferences.getBoolean("nanite", false));
        latencyOptSwitch.setChecked(preferences.getBoolean("latency_opt", false));
    }

    private void autoConfigureLightweightMode() {
        // モバイル軽量化モード時の推奨設定
        grassSwitch.setChecked(false);
        motionBlurSwitch.setChecked(false);
        antiAliasingSwitch.setChecked(false);
        rayTracingSwitch.setChecked(false);
        naniteSwitch.setChecked(false);
        dlssSwitch.setChecked(false);
        vsyncSwitch.setChecked(false);
        latencyOptSwitch.setChecked(true);
        
        Toast.makeText(this, "モバイル軽量化設定を自動適用しました", Toast.LENGTH_SHORT).show();
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("fps_index", fpsSpinner.getSelectedItemPosition());
        editor.putBoolean("show_fps", showFpsSwitch.isChecked());
        editor.putBoolean("dlss", dlssSwitch.isChecked());
        editor.putBoolean("cosmetic_streaming", cosmeticStreamingSwitch.isChecked());
        editor.putBoolean("anti_aliasing", antiAliasingSwitch.isChecked());
        editor.putBoolean("vsync", vsyncSwitch.isChecked());
        editor.putBoolean("video_playback", videoPlaybackSwitch.isChecked());
        editor.putBoolean("motion_blur", motionBlurSwitch.isChecked());
        editor.putBoolean("grass", grassSwitch.isChecked());
        
        // モバイル最適化設定保存
        editor.putBoolean("lightweight_mode", lightweightModeSwitch.isChecked());
        editor.putBoolean("ray_tracing", rayTracingSwitch.isChecked());
        editor.putBoolean("nanite", naniteSwitch.isChecked());
        editor.putBoolean("latency_opt", latencyOptSwitch.isChecked());
        
        editor.apply();
    }

    private void onApplySettings(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("設定の適用");
        
        String selectedFps = fpsOptions[fpsSpinner.getSelectedItemPosition()];
        String message = "選択した設定をFortnite Mobileに適用しますか？\n\n" +
                        "FPS設定: " + selectedFps + "\n" +
                        "軽量化モード: " + (lightweightModeSwitch.isChecked() ? "有効" : "無効") + "\n\n" +
                        "適用後は必ずゲーム内設定メニューを開かないでください。";

        builder.setMessage(message);

        builder.setPositiveButton("適用", (dialog, which) -> {
            applyFortniteSettings();
        });

        builder.setNegativeButton("キャンセル", null);
        builder.show();
    }

    private void applyFortniteSettings() {
        try {
            String fortniteSettingsPath = findFortniteSettingsFile();
            String engineSettingsPath = findEngineSettingsFile();
            
            if (fortniteSettingsPath == null) {
                showErrorDialog("Fortniteの設定ファイルが見つかりませんでした。\n\n" +
                              "1. Fortniteがインストールされているか確認してください\n" +
                              "2. Fortniteを一度起動してログインしてください\n" +
                              "3. 再度お試しください");
                return;
            }

            // GameUserSettings.ini を変更
            modifyGameUserSettings(fortniteSettingsPath);
            
            // Engine.ini を作成・変更（モバイル最適化版）
            createOrModifyEngineSettings(engineSettingsPath);
            
            saveSettings();

            // 成功メッセージ
            String successMessage = "✅ Fortnite Mobile設定が正常に変更されました！\n\n" +
                                  "適用された設定:\n" +
                                  "• FPS: " + fpsOptions[fpsSpinner.getSelectedItemPosition()] + "\n" +
                                  "• モバイル軽量化: " + (lightweightModeSwitch.isChecked() ? "有効" : "無効") + "\n" +
                                  "• タッチレイテンシ最適化: " + (latencyOptSwitch.isChecked() ? "有効" : "無効") + "\n\n" +
                                  "⚠️ 重要：ゲーム内設定メニューを開かないでください！";

            AlertDialog.Builder successBuilder = new AlertDialog.Builder(this);
            successBuilder.setTitle("設定適用完了");
            successBuilder.setMessage(successMessage);
            successBuilder.setPositiveButton("OK", null);
            successBuilder.show();

        } catch (Exception e) {
            showErrorDialog("設定の適用中にエラーが発生しました：\n" + e.getMessage());
        }
    }

    private String findFortniteSettingsFile() {
        String[] possiblePaths = {
            "/data/data/com.epicgames.fortnite/files/UE4Game/FortniteGame/FortniteGame/Saved/Config/Android/GameUserSettings.ini",
            "/storage/emulated/0/Android/data/com.epicgames.fortnite/files/UE4Game/FortniteGame/FortniteGame/Saved/Config/Android/GameUserSettings.ini",
            "/sdcard/Android/data/com.epicgames.fortnite/files/UE4Game/FortniteGame/FortniteGame/Saved/Config/Android/GameUserSettings.ini"
        };

        for (String path : possiblePaths) {
            File file = new File(path);
            if (file.exists() && file.canRead() && file.canWrite()) {
                return path;
            }
        }
        return null;
    }

    private String findEngineSettingsFile() {
        String[] possibleBasePaths = {
            "/data/data/com.epicgames.fortnite/files/UE4Game/FortniteGame/FortniteGame/Saved/Config/Android/",
            "/storage/emulated/0/Android/data/com.epicgames.fortnite/files/UE4Game/FortniteGame/FortniteGame/Saved/Config/Android/",
            "/sdcard/Android/data/com.epicgames.fortnite/files/UE4Game/FortniteGame/FortniteGame/Saved/Config/Android/"
        };

        for (String basePath : possibleBasePaths) {
            File dir = new File(basePath);
            if (dir.exists() && dir.canWrite()) {
                return basePath + "Engine.ini";
            }
        }
        return null;
    }

    private void modifyGameUserSettings(String filePath) throws Exception {
        File settingsFile = new File(filePath);
        String content = new String(Files.readAllBytes(Paths.get(filePath)));
        
        Map<String, String> settings = new HashMap<>();
        
        // FPS設定
        String selectedFpsMode = fpsModes[fpsSpinner.getSelectedItemPosition()];
        settings.put("MobileFPSMode", selectedFpsMode);
        
        // 基本設定
        settings.put("bShowFPS", showFpsSwitch.isChecked() ? "True" : "False");
        settings.put("bEnableDLSSFrameGeneration", dlssSwitch.isChecked() ? "True" : "False");
        settings.put("CosmeticStreamingEnabled", cosmeticStreamingSwitch.isChecked() ? "CodeSet_Enabled" : "CodeSet_Disabled");
        settings.put("bUseVSync", vsyncSwitch.isChecked() ? "True" : "False");
        settings.put("bAllowVideoPlayback", videoPlaybackSwitch.isChecked() ? "True" : "False");
        settings.put("bMotionBlur", motionBlurSwitch.isChecked() ? "True" : "False");
        settings.put("bShowGrass", grassSwitch.isChecked() ? "True" : "False");
        
        // モバイル軽量化設定
        if (lightweightModeSwitch.isChecked()) {
            settings.put("bShowGrass", "False");
            settings.put("FortAntiAliasingMethod", "Disabled");
            settings.put("bEnableDLSSFrameGeneration", "False");
            settings.put("bUseNanite", "False");
            settings.put("bRayTracing", "False");
            // モバイル専用最適化
            settings.put("bAllowLowPowerMode", "False");
            settings.put("bOverrideMobileScalabilityForNewUser", "True");
        }
        
        // タッチレイテンシ最適化（モバイル専用）
        if (latencyOptSwitch.isChecked()) {
            settings.put("bLatencyTweak1", "False");
            settings.put("LatencyTweak2", "1");
            settings.put("bLatencyFlash", "False");
            settings.put("LowInputLatencyModeIsEnabled", "True");
            // モバイル専用タッチ最適化
            settings.put("bUseHeadphoneMode", "True");  // オーディオ遅延削減
        }
        
        // ScalabilityGroups設定（最高パフォーマンス）
        if (lightweightModeSwitch.isChecked()) {
            String scalabilitySection = "[ScalabilityGroups]\n" +
                "sg.ResolutionQuality=100.000000\n" +
                "sg.ViewDistanceQuality=0\n" +
                "sg.ShadowQuality=0\n" +
                "sg.GlobalIlluminationQuality=0\n" +
                "sg.ReflectionQuality=0\n" +
                "sg.PostProcessQuality=0\n" +
                "sg.TextureQuality=0\n" +
                "sg.EffectsQuality=0\n" +
                "sg.FoliageQuality=0\n" +
                "sg.ShadingQuality=0\n" +
                "sg.LandscapeQuality=0\n";
            
            if (content.contains("[ScalabilityGroups]")) {
                content = content.replaceAll("\\[ScalabilityGroups\\][^\\[]*", scalabilitySection);
            } else {
                content += "\n" + scalabilitySection;
            }
        }

        // 設定を適用
        for (Map.Entry<String, String> setting : settings.entrySet()) {
            String key = setting.getKey();
            String value = setting.getValue();
            
            String pattern = key + "=([^\r\n]*)";
            String replacement = key + "=" + value;
            
            if (content.contains(key + "=")) {
                content = content.replaceAll(pattern, replacement);
            } else {
                int insertPos = content.indexOf("[/Script/FortniteGame.FortGameUserSettings]");
                if (insertPos != -1) {
                    insertPos = content.indexOf("\n", insertPos) + 1;
                    content = content.substring(0, insertPos) + key + "=" + value + "\n" + content.substring(insertPos);
                }
            }
        }

        try (FileWriter writer = new FileWriter(settingsFile)) {
            writer.write(content);
        }
    }

    private void createOrModifyEngineSettings(String filePath) throws Exception {
        if (filePath == null) return;
        
        // Engine.iniの内容（モバイル専用最適化）
        String engineContent = "[/Script/Engine.RendererSettings]\n" +
            "r.RayTracing.EnableInGame=False\n" +
            "r.BloomQuality=0\n" +
            "r.LensFlareQuality=0\n" +
            "r.PostProcessAAQuality=0\n" +
            "r.DepthOfFieldQuality=0\n" +
            "r.DefaultFeature.AntiAliasing=0\n" +
            "\n" +
            "[/Script/Engine.RenderSettings]\n" +
            "r.OneFrameThreadLag=0\n" +
            "r.TextureStreaming=0\n" +
            "r.Tonemapper.Sharpen=0.5\n" +
            "\n" +
            "# モバイル専用最適化\n" +
            "[/Script/Engine.MobileRenderSettings]\n" +
            "r.Mobile.ForceFullPrecisionInPS=0\n" +
            "r.Mobile.AllowPixelDepthOffset=0\n" +
            "r.Mobile.EnableStaticAndCSMShadowReceivers=0\n";

        // マウス・キーボード設定は削除（モバイル不要）

        File engineFile = new File(filePath);
        try (FileWriter writer = new FileWriter(engineFile)) {
            writer.write(engineContent);
        }
    }

    private void showErrorDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("エラー");
        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        builder.show();
    }

    public void showHelpDialog(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("VoiD FX モバイル版ヘルプ");
        builder.setMessage("📱 モバイル版使用方法：\n\n" +
                          "1️⃣ 端末設定で120Hz表示を有効にする\n" +
                          "2️⃣ Fortniteをインストール・起動してログイン\n" +
                          "3️⃣ 希望のFPS設定を選択（10000fps=無制限）\n" +
                          "4️⃣ 軽量化モードで最高パフォーマンス\n" +
                          "5️⃣ タッチレイテンシ最適化で遅延削減\n" +
                          "6️⃣ 「設定を適用」をタップ\n" +
                          "7️⃣ Fortniteを起動してプレイ\n\n" +
                          "🚀 モバイル専用機能：\n" +
                          "• 10000fps（無制限）対応\n" +
                          "• モバイル軽量化モード\n" +
                          "• タッチ入力最適化\n" +
                          "• オーディオ遅延削減\n\n" +
                          "⚠️ ゲーム内設定メニューは開かないでください！");
        
        builder.setPositiveButton("OK", null);
        builder.show();
    }
}