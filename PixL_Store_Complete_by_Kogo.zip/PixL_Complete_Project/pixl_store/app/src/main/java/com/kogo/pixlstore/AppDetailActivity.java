package com.kogo.pixlstore;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class AppDetailActivity extends Activity {
    private static final int REQUEST_CODE_SELECT_APK = 1001;
    
    private TextView appNameText;
    private TextView appDescription;
    private TextView statusText;
    private ImageView appIcon;
    private Button actionButton;
    private Button selectApkButton; // 新追加
    private ProgressBar progressBar;

    private String appName;
    private String packageName;
    private String downloadUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_detail);

        // UI要素の初期化
        appNameText = findViewById(R.id.appNameText);
        appDescription = findViewById(R.id.appDescription);
        statusText = findViewById(R.id.statusText);
        appIcon = findViewById(R.id.appIcon);
        actionButton = findViewById(R.id.actionButton);
        selectApkButton = findViewById(R.id.selectApkButton); // 新追加
        progressBar = findViewById(R.id.progressBar);

        Intent intent = getIntent();
        appName = intent.getStringExtra("app_name");
        packageName = intent.getStringExtra("package_name");
        downloadUrl = intent.getStringExtra("download_url");

        appNameText.setText(appName);
        appDescription.setText(intent.getStringExtra("description"));
        statusText.setText(intent.getStringExtra("status"));

        // アイコン設定
        if ("Fortnite".equals(appName)) {
            appIcon.setImageResource(R.drawable.fortnite_icon);
            // Fortniteの場合のみAPK選択ボタンを表示
            selectApkButton.setVisibility(View.VISIBLE);
            selectApkButton.setOnClickListener(this::onSelectApkClick);
        } else if ("VoiD FX".equals(appName)) {
            appIcon.setImageResource(R.drawable.voidfx_icon);
            selectApkButton.setVisibility(View.GONE);
        } else {
            appIcon.setImageResource(R.drawable.ic_android);
            selectApkButton.setVisibility(View.GONE);
        }

        actionButton.setOnClickListener(this::onActionButtonClick);
        
        updateUI();
    }

    private void updateUI() {
        boolean isInstalled = isAppInstalled(packageName);
        File apkFile = getApkFile();

        if (isInstalled) {
            actionButton.setText("起動");
            actionButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
        } else if (apkFile.exists()) {
            actionButton.setText("インストール");
            actionButton.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_dark));
        } else {
            actionButton.setText("ダウンロード");
            actionButton.setBackgroundColor(getResources().getColor(android.R.color.holo_orange_dark));
        }
        
        // Fortniteの場合、APK選択ボタンのテキストを更新
        if ("Fortnite".equals(appName)) {
            if (apkFile.exists()) {
                selectApkButton.setText("APKを更新");
            } else {
                selectApkButton.setText("APKファイル選択");
            }
        }
    }

    // 新機能：APKファイル選択
    private void onSelectApkClick(View view) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/vnd.android.package-archive");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        
        try {
            startActivityForResult(
                Intent.createChooser(intent, "Fortnite APKファイルを選択してください"), 
                REQUEST_CODE_SELECT_APK
            );
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "ファイルマネージャーが見つかりません", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == REQUEST_CODE_SELECT_APK && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                Uri selectedUri = data.getData();
                copySelectedApkFile(selectedUri);
            }
        }
    }

    // 選択されたAPKファイルをアプリ内ストレージにコピー
    private void copySelectedApkFile(Uri sourceUri) {
        progressBar.setVisibility(View.VISIBLE);
        statusText.setText("APKファイルをコピー中...");
        
        new Thread(() -> {
            try {
                File destinationFile = getApkFile();
                
                // 既存ファイルがあれば削除
                if (destinationFile.exists()) {
                    destinationFile.delete();
                }
                
                // 親ディレクトリを作成
                destinationFile.getParentFile().mkdirs();
                
                // ファイルをコピー
                InputStream inputStream = getContentResolver().openInputStream(sourceUri);
                FileOutputStream outputStream = new FileOutputStream(destinationFile);
                
                byte[] buffer = new byte[1024];
                int length;
                long totalBytes = 0;
                
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                    totalBytes += length;
                }
                
                inputStream.close();
                outputStream.close();
                
                // APKファイルの検証
                if (destinationFile.exists() && destinationFile.length() > 0) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        statusText.setText("✅ APKファイル準備完了 (" + formatFileSize(totalBytes) + ")");
                        updateUI();
                        Toast.makeText(this, "✅ Fortnite APKが正常にコピーされました！", Toast.LENGTH_LONG).show();
                        
                        // 自動インストールの確認ダイアログ
                        new AlertDialog.Builder(this)
                            .setTitle("📱 Fortnite更新")
                            .setMessage("新しいAPKファイルが準備できました。\n今すぐインストールしますか？")
                            .setPositiveButton("今すぐインストール", (dialog, which) -> {
                                installApp(destinationFile);
                            })
                            .setNegativeButton("後でインストール", null)
                            .show();
                    });
                } else {
                    throw new Exception("ファイルコピーに失敗しました");
                }
                
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    statusText.setText("❌ コピー失敗: " + e.getMessage());
                    Toast.makeText(this, "❌ APKコピーに失敗しました: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void onActionButtonClick(View view) {
        boolean isInstalled = isAppInstalled(packageName);
        File apkFile = getApkFile();

        if (isInstalled) {
            launchApp();
        } else if (apkFile.exists()) {
            installApp(apkFile);
        } else {
            if (downloadUrl.isEmpty()) {
                showVoidFxInfo();
            } else {
                downloadApp();
            }
        }
    }

    private void showVoidFxInfo() {
        new AlertDialog.Builder(this)
            .setTitle("VoiD FX について")
            .setMessage("VoiD FXはFortniteの設定を最適化するツールです。\n\n" +
                       "📱 主な機能:\n" +
                       "• 10000fps（無制限）対応\n" +
                       "• モバイル軽量化モード\n" +
                       "• タッチ入力最適化\n" +
                       "• Engine.ini自動生成\n\n" +
                       "VoiD FXはこのPixLアプリに内蔵されています。")
            .setPositiveButton("VoiD FXを起動", (dialog, which) -> {
                Intent intent = new Intent(this, VoidFxActivity.class);
                startActivity(intent);
            })
            .setNegativeButton("キャンセル", null)
            .show();
    }

    private void downloadApp() {
        // ダウンロード機能（従来のまま）
        Toast.makeText(this, "ダウンロード機能は開発中です", Toast.LENGTH_SHORT).show();
    }

    private void installApp(File apkFile) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri apkUri = FileProvider.getUriForFile(this, 
                getApplicationContext().getPackageName() + ".provider", apkFile);
            intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
            
            statusText.setText("📱 インストール中...");
        } catch (Exception e) {
            statusText.setText("❌ インストール失敗: " + e.getMessage());
            Toast.makeText(this, "インストールに失敗しました: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void launchApp() {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
            if (intent != null) {
                startActivity(intent);
                statusText.setText("🚀 " + appName + " を起動しました");
            } else {
                Toast.makeText(this, "アプリを起動できませんでした", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "起動エラー: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isAppInstalled(String packageName) {
        try {
            getPackageManager().getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private File getApkFile() {
        return new File(getExternalFilesDir("apks"), appName + ".apk");
    }
    
    // ファイルサイズをフォーマット
    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format("%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }
}